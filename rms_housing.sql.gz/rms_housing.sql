-- Adminer 4.8.1 MySQL 8.0.31 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `age_of_properties`;
CREATE TABLE `age_of_properties` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `age_of_properties` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(5,	'0-1',	'1',	'2023-04-27 06:00:48',	'2023-04-27 06:00:48'),
(6,	'1-5',	'1',	'2023-04-27 06:00:55',	'2023-04-27 06:00:55');

DROP TABLE IF EXISTS `amenities`;
CREATE TABLE `amenities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `amenities` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(3,	'Amenities 1',	'1',	'2023-04-27 06:01:47',	'2023-04-27 06:01:47'),
(4,	'Amenities 2',	'1',	'2023-04-27 06:01:53',	'2023-04-27 06:01:53'),
(5,	'Amenities 3',	'1',	'2023-04-27 06:01:58',	'2023-04-27 06:01:58');

DROP TABLE IF EXISTS `api_audits`;
CREATE TABLE `api_audits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `api_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `response_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `time_taken` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `available_froms`;
CREATE TABLE `available_froms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `available_froms` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'Available From Title',	'1',	'2023-04-27 06:00:28',	'2023-04-27 06:00:28');

DROP TABLE IF EXISTS `building_types`;
CREATE TABLE `building_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `building_types` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'sss',	'1',	NULL,	NULL);

DROP TABLE IF EXISTS `cms_pages`;
CREATE TABLE `cms_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cms_pages` (`id`, `title`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1,	'Privacy policy',	'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',	'0',	'2023-04-28 13:28:56',	'2023-04-28 07:58:56'),
(2,	'Terms  of service',	'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',	'1',	'2023-04-28 13:04:24',	'2023-04-28 07:34:24');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `furnishing_statuses`;
CREATE TABLE `furnishing_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `furnishing_statuses` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(4,	'Furnishing Status Title',	'1',	'2023-04-27 06:00:38',	'2023-04-27 06:00:38');

DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `locations` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(1,	'Surat',	'0',	'2023-05-11 10:46:46',	'2023-05-11 05:16:46'),
(2,	'Vesu',	'1',	'2023-05-11 05:17:38',	'2023-05-11 05:17:38');

DROP TABLE IF EXISTS `measurements`;
CREATE TABLE `measurements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `measurements` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'Measuremen',	'1',	'2023-04-27 06:01:24',	'2023-04-27 06:01:24');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(3,	'2014_10_12_100000_create_password_resets_table',	1),
(4,	'2019_08_19_000000_create_failed_jobs_table',	1),
(5,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(6,	'2023_04_24_112316_create_property_fors_table',	2),
(7,	'2023_04_26_083908_create_building_types_table',	3),
(8,	'2023_04_26_091228_create_property_types_table',	4),
(9,	'2023_04_26_102057_create_available_froms_table',	5),
(10,	'2023_04_26_104039_create_furnishing_statuses_table',	6),
(11,	'2023_04_26_111216_create_age_of_properties_table',	7),
(12,	'2023_04_26_113453_create_property_views_table',	8),
(13,	'2023_04_26_115259_create_measurements_table',	9),
(14,	'2023_04_26_120707_create_price_types_table',	10),
(15,	'2023_04_26_122245_create_security_deposits_table',	11),
(16,	'2023_04_26_131727_create_security_deposits_table',	12),
(17,	'2023_04_27_090938_create_amenities_table',	13),
(18,	'2023_04_27_094257_create_properties_table',	14),
(19,	'2023_04_27_113409_create_property_images_table',	15),
(20,	'2023_04_28_122744_create_cms_pages_table',	16),
(21,	'2023_05_10_112330_create_visitors_table',	17),
(22,	'2023_05_11_102312_create_locations_table',	18);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `price_types`;
CREATE TABLE `price_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `price_types` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'Title',	'1',	NULL,	NULL);

DROP TABLE IF EXISTS `properties`;
CREATE TABLE `properties` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `project_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `locality` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `property_for_id` int NOT NULL,
  `property_type_id` int NOT NULL,
  `building_type_id` int DEFAULT NULL,
  `available_from_id` int NOT NULL,
  `furnishing_status_id` int NOT NULL,
  `age_of_property_id` int NOT NULL,
  `property_view_id` int NOT NULL,
  `measurement_id` int NOT NULL,
  `price_type_id` int NOT NULL,
  `security_deposit_id` int NOT NULL,
  `amenity_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_bedrooms` int NOT NULL,
  `no_of_bathrooms` int NOT NULL,
  `no_of_parking` int NOT NULL,
  `bachelors_allowed` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `plot_area` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `super_built_up_area` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `carpet_area` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_in_inr` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `maintenance` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `is_verified` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `properties` (`id`, `user_id`, `project_name`, `project_description`, `location`, `locality`, `property_for_id`, `property_type_id`, `building_type_id`, `available_from_id`, `furnishing_status_id`, `age_of_property_id`, `property_view_id`, `measurement_id`, `price_type_id`, `security_deposit_id`, `amenity_id`, `no_of_bedrooms`, `no_of_bathrooms`, `no_of_parking`, `bachelors_allowed`, `plot_area`, `super_built_up_area`, `carpet_area`, `price_in_inr`, `maintenance`, `status`, `is_verified`, `created_at`, `updated_at`) VALUES
(24,	14,	'APi Test Project',	'APi Test description',	'Surat',	'ABC',	7,	2,	NULL,	2,	4,	5,	2,	2,	2,	2,	'3,4',	4,	5,	1,	'yes',	'100sq',	'100p',	'100',	'10L',	'600',	'1',	'1',	'2023-05-05 05:51:38',	'2023-05-09 07:25:23'),
(26,	14,	'sateesh',	'APi Test',	'Surat',	'ABC',	7,	2,	NULL,	2,	4,	5,	2,	2,	2,	2,	'3',	4,	5,	1,	'yes',	'100sq',	'100p',	'100',	'10L',	'600',	'1',	'1',	'2023-05-09 03:46:39',	'2023-05-09 07:22:14'),
(27,	15,	'ratnesh',	'ratnesh',	'Surat',	'ABC',	7,	2,	NULL,	2,	4,	5,	2,	2,	2,	2,	'3,4',	4,	5,	1,	'yes',	'100sq',	'100p',	'100',	'10L',	'600',	'1',	'1',	'2023-05-09 03:47:12',	'2023-05-09 07:22:47');

DROP TABLE IF EXISTS `property_fors`;
CREATE TABLE `property_fors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `property_for` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `property_fors` (`id`, `property_for`, `status`, `created_at`, `updated_at`) VALUES
(7,	'Property For',	'1',	'2023-04-27 05:59:53',	'2023-04-27 05:59:53');

DROP TABLE IF EXISTS `property_images`;
CREATE TABLE `property_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `property_id` int NOT NULL,
  `image_path` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `property_images` (`id`, `property_id`, `image_path`, `created_at`, `updated_at`) VALUES
(38,	18,	'http://localhost/rms_housing/public/storage/property_image/5de41246-6598-404a-ae3a-a9d86f576875.jpg',	'2023-05-02 04:15:09',	'2023-05-02 04:15:09'),
(37,	18,	'http://localhost/rms_housing/public/storage/property_image/bc3e4e3f-bb35-43b1-9c08-365da951e344.jpg',	'2023-05-02 04:15:09',	'2023-05-02 04:15:09'),
(33,	15,	'http://localhost/rms_housing/public/storage/property_image/76227f05-61e3-42d1-9194-a2fd49526344.jpg',	'2023-05-02 03:29:02',	'2023-05-02 03:29:02'),
(34,	15,	'http://localhost/rms_housing/public/storage/property_image/e5ef77e9-f3a6-4a47-a66c-f112071f225e.jpg',	'2023-05-02 03:29:02',	'2023-05-02 03:29:02'),
(36,	17,	'http://localhost/rms_housing/public/storage/property_image/f1c5762a-c8e1-433f-a478-307b81f696f9.jpg',	'2023-05-02 04:14:50',	'2023-05-02 04:14:50'),
(35,	17,	'http://localhost/rms_housing/public/storage/property_image/04597e3e-3cbb-42a2-b691-ccc61b16e12c.jpg',	'2023-05-02 04:14:50',	'2023-05-02 04:14:50'),
(31,	15,	'http://localhost/rms_housing/public/storage/property_image/ab04b4b8-7adc-4404-bb19-33737f867d5a.jpg',	'2023-05-02 03:20:42',	'2023-05-02 03:20:42'),
(30,	15,	'http://localhost/rms_housing/public/storage/property_image/ef6260e2-cd2b-4424-8899-3469cdcc097f.jpg',	'2023-05-02 03:20:42',	'2023-05-02 03:20:42'),
(39,	17,	'http://localhost/rms_housing/public/storage/property_image/6ac9e4c0-3426-4ff0-9c56-28e99a45833b.jpg',	'2023-05-02 04:16:59',	'2023-05-02 04:16:59'),
(40,	17,	'http://localhost/rms_housing/public/storage/property_image/d2c76bab-5117-4eaf-853d-cbb0af6ae011.jpg',	'2023-05-02 04:16:59',	'2023-05-02 04:16:59'),
(41,	19,	'http://localhost/rms_housing/public/storage/property_image/2f3b0354-7493-45cb-82ee-9cf20404b529.png',	'2023-05-02 04:35:36',	'2023-05-02 04:35:36'),
(42,	20,	'http://localhost/rms_housing/public/storage/property_image/f8365ee6-38d3-4066-b9dd-c4bdb030ca2d.jpg',	'2023-05-02 04:36:29',	'2023-05-02 04:36:29'),
(43,	20,	'http://localhost/rms_housing/public/storage/property_image/95e8b11c-f656-4b54-8842-cfb3ac06cdb5.jpg',	'2023-05-02 04:36:29',	'2023-05-02 04:36:29'),
(44,	20,	'http://localhost/rms_housing/public/storage/property_image/1e67fa7a-4d0d-47b9-a796-c0d6fa65c502.jpg',	'2023-05-02 04:38:28',	'2023-05-02 04:38:28'),
(45,	20,	'http://localhost/rms_housing/public/storage/property_image/6267ebb2-1092-43d5-862e-a626086835ad.jpg',	'2023-05-02 04:38:28',	'2023-05-02 04:38:28'),
(46,	21,	'http://localhost/rms_housing/public/storage/property_image/24531fa5-478e-44ee-9396-aa946b1aeaff.jpg',	'2023-05-05 05:27:33',	'2023-05-05 05:27:33'),
(47,	22,	'http://localhost/rms_housing/public/storage/property_image/3e2b6a3e-7535-4479-add8-0fd19511afe9.jpg',	'2023-05-05 05:29:03',	'2023-05-05 05:29:03'),
(48,	23,	'http://localhost/rms_housing/public/storage/property_image/c607067e-2218-4c68-8b15-1789090746b1.jpg',	'2023-05-05 05:50:15',	'2023-05-05 05:50:15'),
(49,	24,	'http://localhost/rms_housing/public/storage/property_image/afe90a26-8acb-4f25-a1fc-a83a575562fd.jpg',	'2023-05-05 05:51:39',	'2023-05-05 05:51:39'),
(50,	26,	'http://localhost/rms_housing/public/storage/property_image/3a69194f-3bf8-4aa6-970d-0878f49eb7e1.jpg',	'2023-05-09 03:46:39',	'2023-05-09 03:46:39'),
(51,	27,	'http://localhost/rms_housing/public/storage/property_image/2f059cbd-63a1-4f3b-ae10-0340e20e1373.jpg',	'2023-05-09 03:47:12',	'2023-05-09 03:47:12'),
(52,	24,	'http://localhost/rms_housing/public/storage/property_image/9cbeb889-5f51-4382-b482-0f9bb87c29a4.png',	'2023-05-09 07:21:16',	'2023-05-09 07:21:16'),
(53,	26,	'http://localhost/rms_housing/public/storage/property_image/65b42748-3d06-4aaf-a993-18b2624e0877.jpg',	'2023-05-09 07:22:14',	'2023-05-09 07:22:14'),
(54,	27,	'public/property_image//fadf8395-8853-48c7-837a-67d6b861ccde.jpg',	'2023-05-11 04:16:36',	'2023-05-11 04:16:36');

DROP TABLE IF EXISTS `property_types`;
CREATE TABLE `property_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `property_types` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'Property Type Title',	'1',	'2023-04-27 06:00:12',	'2023-04-27 06:00:12');

DROP TABLE IF EXISTS `property_views`;
CREATE TABLE `property_views` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `property_views` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'Property View',	'1',	'2023-04-27 06:01:13',	'2023-04-27 06:01:13');

DROP TABLE IF EXISTS `security_deposits`;
CREATE TABLE `security_deposits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `security_deposits` (`id`, `title`, `status`, `created_at`, `updated_at`) VALUES
(2,	'1000',	'1',	'2023-04-27 06:01:37',	'2023-04-27 06:01:37');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_session_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_block` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `otp` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_otp_verified` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `address`, `profile_image`, `mobile_no`, `whatsapp_no`, `user_type`, `device_token`, `remember_token`, `user_session_token`, `email_verified_at`, `is_block`, `otp`, `is_otp_verified`, `created_at`, `updated_at`) VALUES
(1,	'Admin',	'rmsadmin@gmail.com',	'$2y$10$O69u93k9/I2e7OpnTkERFe9TkwAAijysuLO./zajomXsxebw9SDD6',	NULL,	'http://localhost/rms_housing/public/storage/profile_image/5fd28611-04a8-43d3-8202-19411147c42f.jpg',	NULL,	NULL,	NULL,	NULL,	NULL,	'$2y$10$bduAdcRDymaX2RYayQPjwu.kXV4m6Ny8RJqHysO8PYFHF4NimoiiK',	NULL,	'1',	NULL,	'0',	'2023-05-05 06:31:33',	'2023-05-09 06:41:12'),
(14,	'sateesh yadav',	'sateesh@gmail.com',	NULL,	'surat',	'http://localhost/rms_housing/public/storage/profile_image/cc28b3c6-cb42-441f-bae3-9a184450fffc.jpg',	'7990901767',	'1234567798',	'user',	'device_token',	NULL,	'$2y$10$Dor4aGFx6GJDc4kIOEwGo.Jsc0U2AmDotsX.tYm6vJoAty3PEVuN.',	NULL,	'1',	NULL,	'1',	'2023-05-09 03:30:05',	'2023-05-09 03:32:49'),
(15,	'ratnesh',	'ratnesh@gmail.com',	NULL,	'surat',	'http://localhost/rms_housing/public/storage/profile_image/cc28b3c6-cb42-441f-bae3-9a184450fffc.jpg',	'7990901767',	'1234567798',	'user',	'device_token',	NULL,	'$2y$10$Dor4aGFx6GJDc4kIOEwGo.Jsc0U2AmDotsX.tYm6vJoAty3PEVuN.',	NULL,	'0',	NULL,	'1',	'2023-05-09 03:30:05',	'2023-05-09 07:24:33'),
(16,	'test',	'test@gmail.com',	NULL,	'surat',	'http://localhost/rms_housing/public/storage/profile_image/cc28b3c6-cb42-441f-bae3-9a184450fffc.jpg',	'7990901767',	'1234567798',	'user',	'device_token',	NULL,	'$2y$10$Dor4aGFx6GJDc4kIOEwGo.Jsc0U2AmDotsX.tYm6vJoAty3PEVuN.',	NULL,	'1',	NULL,	'1',	'2023-05-09 03:30:05',	'2023-05-09 07:29:09'),
(17,	NULL,	NULL,	NULL,	NULL,	NULL,	'9586552715',	NULL,	'user',	'device_token',	NULL,	'$2y$10$ez.9b4Luw0kSQ.mIrusP8O6JZ66SF86079WVuOpA4fDLNzusAdH.m',	NULL,	'1',	'1234',	'0',	'2023-05-11 05:53:32',	'2023-05-11 05:57:10');

DROP TABLE IF EXISTS `visitors`;
CREATE TABLE `visitors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `visitors` (`id`, `ip`, `created_at`, `updated_at`) VALUES
(10,	'127.0.0.1',	'2023-05-10 06:31:43',	'2023-05-10 06:31:43');

-- 2024-03-03 15:36:50
